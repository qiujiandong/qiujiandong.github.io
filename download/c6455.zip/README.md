# TMS320C6455入门实践相关工程文件
CCS v6.2.0
编译器：C6000 Compiler 7.4.18
 - csl_c6455.zip
   - 这里的是编译CSL静态库的四个工程
 - Blink.zip
   - 主程序，利用定时器中断实现的LED闪烁功能。LED在GPIO1上，定时器每隔1s产生一次中断
 - FlashBurn.zip
   - 用于烧录主程序的程序，包含S29JL064J Flash的部分驱动