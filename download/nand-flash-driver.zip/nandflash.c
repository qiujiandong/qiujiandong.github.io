#include <nandflash.h>

static inline void WriteCmd(Uint8 cmd)
{
	*(Uint8 *)NAND_CLE_ADDR = cmd;
	return;
}

static inline void WriteAddr(Uint8 addr)
{
	*(Uint8 *)NAND_ALE_ADDR = addr;
	return;
}

static inline Bool isAnyError()
{
	WriteCmd(0x70);
	return (Bool)(*(Uint8 *)NAND_BASE_ADDR & 0x03);
}

static inline Bool isCacheReady()
{
	WriteCmd(0x70);
	return (Bool)(*(Uint8 *)NAND_BASE_ADDR & 0x40);
}

static inline Bool isProgramFinished()
{
	WriteCmd(0x70);
	return (*(Uint8 *)NAND_BASE_ADDR & 0x60) == 0x60 ;
}

/*
 * To Check if NAND Flash is proper working
 */
Bool CheckS34MS01G2()
{
	int i;
	Uint8 tmp[4];
	WriteCmd(0x90);
	WriteAddr(0x00);
	for(i = 0; i<4; i++){
		tmp[i] = *(Uint8 *)NAND_BASE_ADDR;
	}
	if(tmp[0] == NAND_ID1 && tmp[1] == NAND_ID2 && tmp[2] == NAND_ID3 && tmp[3] == NAND_ID4){
		return TRUE;
	}
	else{
		return FALSE;
	}
}

/*
 * blockAddr must between 0~1023 (can equal to zero or 1023)
 */
Bool BlockErase(Uint16 blockAddr)
{
	if(blockAddr >= PLANE_SIZE) return FALSE;

	Uint8 rowAddr1, rowAddr2;
	rowAddr1 = (Uint8)((blockAddr & 0x0003)<<6);
	rowAddr2 = (Uint8)(blockAddr>>2 & 0x00FF);

	WriteCmd(0x60);
	WriteAddr(rowAddr1);
	WriteAddr(rowAddr2);
	WriteCmd(0xD0);

	//wait for erasing finish
	while(!isCacheReady());
	//check if there is any error
	if(isAnyError()) return FALSE;
	else return TRUE;
}

/*
 * program a page
 * start from col address 0
 * pageAddr must between 0~63 (can equal to zero or 63)
 * blockAddr must between 0~1023 (can equal to zero or 1023)
 * len must between 1~2048 (can equal to 1 or 2048)
 */
Bool ProgramPage(
	Uint8 pageAddr,
	Uint16 blockAddr,
	const Uint8 *src,
	Uint16 len
){
	int i;
	Uint8 colAddr1, colAddr2, rowAddr1, rowAddr2;

	if(len > PAGE_SIZE || pageAddr >= BLOCK_SIZE || blockAddr >= PLANE_SIZE)
		return FALSE;

	colAddr1 = 0x00;
	colAddr2 = 0x00;
	rowAddr1 = pageAddr&(0x3F) | (Uint8)((blockAddr & 0x0003)<<6);
	rowAddr2 = (Uint8)(blockAddr>>2 & 0x00FF);

	WriteCmd(0x80);
	WriteAddr(colAddr1);
	WriteAddr(colAddr2);
	WriteAddr(rowAddr1);
	WriteAddr(rowAddr2);

	for(i = 0; i<len; i++){
		*(Uint8 *)NAND_BASE_ADDR = *src++;
	}

	WriteCmd(0x10);

	while(!isCacheReady());

	if(isAnyError()) return FALSE;
	else return TRUE;
}

/*
 * program a block (many pages) with cache
 * start from col address 0
 * start from page address 0
 * blockAddr must between 0~1023 (can equal to zero or 1023)
 * pageNum must between 1~64 (can equal to 1 or 64)
 */
Bool ProgramBlock(
	Uint16 blockAddr,
	const Uint8 *src,
	Uint32 pageNum
){
	int i;
	Uint8 pageAddr, rowAddr1, rowAddr2;

	if(pageNum > BLOCK_SIZE || blockAddr >= PLANE_SIZE)
		return FALSE;

	rowAddr2 = (Uint8)(blockAddr>>2 & 0x00FF);

	for(pageAddr = 0; pageAddr < pageNum; pageAddr++){
		rowAddr1 = pageAddr&(0x3F) | (Uint8)((blockAddr & 0x0003)<<6);

		WriteCmd(0x80);
		WriteAddr(0x00);
		WriteAddr(0x00);
		WriteAddr(rowAddr1);
		WriteAddr(rowAddr2);

		for(i = 0; i<PAGE_SIZE; i++){
			*(Uint8 *)NAND_BASE_ADDR = *src++;
		}
		WriteCmd(0x15);

		while(!isCacheReady());
		if(isAnyError()) return FALSE;
		else continue;
	}

	while(!isProgramFinished());
	if(isAnyError()) return FALSE;
	else return TRUE;
}

/*
 * read one page
 * start form col address 0
 * pageAddr must between 0~63 (can equal to zero or 63)
 * blockAddr must between 0~1023 (can equal to zero or 1023)
 * len must between 1~2048 (can equal to 1 or 2048)
 */
Bool ReadPage(
	Uint8 pageAddr,
	Uint16 blockAddr,
	Uint8 *dst,
	Uint16 len
){
	int i;
	Uint8 colAddr1, colAddr2, rowAddr1, rowAddr2;

	if(len > PAGE_SIZE || pageAddr > BLOCK_SIZE || blockAddr > PLANE_SIZE)
		return FALSE;

	colAddr1 = 0x00;
	colAddr2 = 0x00;
	rowAddr1 = pageAddr&(0x3F) | (Uint8)((blockAddr & 0x0003)<<6);
	rowAddr2 = (Uint8)(blockAddr>>2 & 0x00FF);

	WriteCmd(0x00);
	WriteAddr(colAddr1);
	WriteAddr(colAddr2);
	WriteAddr(rowAddr1);
	WriteAddr(rowAddr2);
	WriteCmd(0x30);

	while(!isCacheReady());

	WriteCmd(0x00);
	for(i = 0; i<PAGE_SIZE; i++){
		*(dst+i) = *(Uint8 *)NAND_BASE_ADDR;
	}
	return TRUE;
}

/*
 * read a block (many pages) with cache
 * start from col address 0
 * start from page address 0
 * blockAddr must between 0~1023 (can equal to zero or 1023)
 * pageNum must between 2~64 (can equal to 2 or 64)
 */
Bool ReadBlock(
	Uint16 blockAddr,
	Uint8 *dst,
	Uint16 pageNum
){
	int i;
	Uint8 colAddr1, colAddr2, rowAddr1, rowAddr2, pageAddr;

	if(blockAddr > PLANE_SIZE || pageNum < 2 || pageNum > BLOCK_SIZE)
		return FALSE;

	colAddr1 = 0x00;
	colAddr2 = 0x00;
	rowAddr1 = (Uint8)((blockAddr & 0x0003)<<6);
	rowAddr2 = (Uint8)(blockAddr>>2 & 0x00FF);

	WriteCmd(0x00);
	WriteAddr(colAddr1);
	WriteAddr(colAddr2);
	WriteAddr(rowAddr1);
	WriteAddr(rowAddr2);
	WriteCmd(0x30);
	while(!isCacheReady());

	for(pageAddr = 0; pageAddr < pageNum - 1; pageAddr++){
		WriteCmd(0x31);
		while(!isCacheReady());
		WriteCmd(0x00);
		for(i = 0; i<PAGE_SIZE; i++){
			*dst++ = *(Uint8 *)NAND_BASE_ADDR;
		}
	}
	WriteCmd(0x3F);
	while(!isCacheReady());
	WriteCmd(0x00);
	for(i = 0; i<PAGE_SIZE; i++){
		*dst++ = *(Uint8 *)NAND_BASE_ADDR;
	}
	return TRUE;
}
