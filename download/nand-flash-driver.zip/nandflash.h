/*
 * nandflash.h
 *
 *  Created on: 2021.10.8
 *      Author: jayden
 */

#ifndef INC_NANDFLASH_H_
#define INC_NANDFLASH_H_

#include <tistdtypes.h>

#define NAND_BASE_ADDR 	(0x74000000)
#define NAND_CLE_ADDR	(0x74001000)
#define NAND_ALE_ADDR	(0x74000800)

#define PAGE_SIZE		(0x800)
#define BLOCK_SIZE		(0x40)
#define PLANE_SIZE		(0x400)

#define NAND_ID1		(0x01)
#define NAND_ID2		(0xA1)
#define NAND_ID3		(0x80)
#define NAND_ID4		(0x15)

Bool CheckS34MS01G2();
Bool BlockErase(Uint16 blockAddr);

Bool ProgramPage(
	Uint8 pageAddr,
	Uint16 blockAddr,
	const Uint8 *src,
	Uint16 len
);

Bool ProgramBlock(
	Uint16 blockAddr,
	const Uint8 *src,
	Uint32 pageNum
);

Bool ReadPage(
	Uint8 pageAddr,
	Uint16 blockAddr,
	Uint8 *dst,
	Uint16 len
);

Bool ReadBlock(
	Uint16 blockAddr,
	Uint8 *dst,
	Uint16 pageNum
);

#endif /* INC_NANDFLASH_H_ */
